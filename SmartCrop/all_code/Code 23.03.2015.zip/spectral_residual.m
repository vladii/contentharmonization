
clear all;

function img = bresenhamLine(img, startPoint, endPoint, color)

if( any(color > 255) )
    error 'RGB colors must be between 0 and 255';
end

%Check for vertical line, x0 == x1
if( startPoint(1) == endPoint(1) )
    %Draw vertical line
    for i = (startPoint(2):endPoint(2))
        img(startPoint(1), i, :) = color;
    end
end

%Simplified Bresenham algorithm
dx = abs(endPoint(1) - startPoint(1));
dy = abs(endPoint(2) - startPoint(2));

if(startPoint(1) < endPoint(1))
    sx = 1;
else
    sx = -1;
end

if(startPoint(2) < endPoint(2))
    sy = 1;
else
    sy = -1;
end

err = dx - dy;
pixel = startPoint;

while(true)
    img(pixel(1), pixel(2), :) = color;

    if( pixel == endPoint )
        break;
    end

    e2 = 2*err;

    if( e2 > -dy )
        err = err - dy;
        pixel(1) = pixel(1) + sx;
    end

    if( e2 < dx )
        err = err + dx;
        pixel(2) = pixel(2) + sy;
    end
end
end

addpath('.');


saldir = "./saliencymap/";
imgRoot = "./testelephants/";

imnames = dir([imgRoot '*']);

resize_factor = 256;

average_matrix = zeros(resize_factor, resize_factor);

known_average_matrix = dlmread('amplitude-average-matrix.txt');

for ii=1:length(imnames)
    imname = [imgRoot imnames(ii).name];
    %% Read image from file
    inImg = im2double(rgb2gray(imread(imname)));
    %% inImg = imresize(inImg, resize_factor/size(inImg, 2));
    inImg = imresize(inImg, [resize_factor resize_factor]);

    originalImage = imread(imname);
    originalImage = imresize(originalImage, [resize_factor resize_factor]);

    outname = [saldir imnames(ii).name(1:end-4) '_scaled' '.png'];
    imwrite(inImg, outname);

    %% ---------------------- Spectral Residual (FFT) Saliency Map -------------------- %%

    %% Spectral Residual
    myFFT = fft2(inImg); 
    myLogAmplitude = log(abs(myFFT));
    myPhase = angle(myFFT);

    %% instead of applying this filter, use previous known information
    mySpectralResidual = myLogAmplitude - imfilter(myLogAmplitude, fspecial('average', 3), 'replicate');
    %% mySpectralResidual = myLogAmplitude - known_average_matrix;

    %% compute saliency map
    saliencyMap = abs(ifft2(exp(mySpectralResidual + i*myPhase))).^2;

    %% compute element-by-element sum in order to find the average log-amplitude
    average_matrix = average_matrix + myLogAmplitude;

    %% After Effect
    saliencyMap = mat2gray(imfilter(saliencyMap, fspecial('gaussian', [10, 10], 2.5)));
    %% imshow(saliencyMap);

    %% write saliency map
    outname = [saldir imnames(ii).name(1:end-4) '_saliency' '.png'];
    imwrite(saliencyMap, outname);

    %% ----------------------------- Compute OLD Points of Interest --------------------- %%

    %% compute points of interest
    threshold = mean(mean(saliencyMap, 2)) * 2;
    index = 0;
    for pp = 1:size(saliencyMap, 1)
        for kk = 1:size(saliencyMap, 2)
            if saliencyMap(pp, kk) > threshold
                O(pp, kk) = 1;

                index ++;
                points(index, 1) = pp;
                points(index, 2) = kk;

                %% extra dimensions
                %% points(index, 3) = sqrt(originalImage(pp, kk, 1));
                %% points(index, 4) = sqrt(originalImage(pp, kk, 2));
                %% points(index, 5) = sqrt(originalImage(pp, kk, 3));
            else
                O(pp, kk) = inImg(pp, kk);
            end
        end
    end

    %% write points of interest
    outname = [saldir imnames(ii).name(1:end-4) '_old_interest' '.png'];
    imwrite(O, outname);

    %% --------------------- Saliency Map via Graph Based Manifold --------------------- %%

    graph_based_manifold_saliency_map = graph_based_manifold(imnames(ii).name);

    %% Combine these two methods (for better results?)
    %% Combine using sqrt(). (TODO: try another methods, too)
    for pp = 1:size(saliencyMap, 1)
        for kk = 1:size(saliencyMap, 2)
            saliencyMap(pp, kk) = saliencyMap(pp, kk) * sqrt(graph_based_manifold_saliency_map(pp, kk));
        end
    end

    %% ----------------------------- Compute NEW Points of Interest --------------------- %%

    %% compute points of interest
    threshold = mean(mean(saliencyMap, 2)) * 2;
    index = 0;
    for pp = 1:size(saliencyMap, 1)
         for kk = 1:size(saliencyMap, 2)
             if saliencyMap(pp, kk) > threshold
                 O(pp, kk) = 1;

                index ++;
                points(index, 1) = pp;
                points(index, 2) = kk;

                %% extra dimensions
                %% points(index, 3) = sqrt(originalImage(pp, kk, 1));
                %% points(index, 4) = sqrt(originalImage(pp, kk, 2));
                %% points(index, 5) = sqrt(originalImage(pp, kk, 3));
             else
                 O(pp, kk) = inImg(pp, kk);
             end
         end
    end

    %% write points of interest
    outname = [saldir imnames(ii).name(1:end-4) '_new_interest' '.png'];
    imwrite(O, outname);

    %% write interest points
    outname = [saldir imnames(ii).name(1:end-4) '_points' '.txt'];
    save(outname, 'points', '-ascii');

    %{
    %% ----------------------------------- PHASE 2 ------------------------------------ %%
    %% compute clusters
    %% NR_CLUSTERS = sqrt(size(points, 1));
    NR_CLUSTERS = 4;
    [idx, centers] = kmeans(points, NR_CLUSTERS);

    colors = [];
    for pp = 1 : NR_CLUSTERS
        colors(pp, :) = randi([0 255], 1, 3);
    end

    newImg = imread(imname);
    newImg = imresize(newImg, [resize_factor resize_factor]);

    for pp = 1 : size(points, 1)
        newImg(points(pp, 1), points(pp, 2), :) = colors(idx(pp), :);
    end

    for pp = 1 : NR_CLUSTERS
        points_cluster = [];
        idx_cluster = 0;

        for qq = 1 : size(idx)
            if idx(qq) == pp
                idx_cluster ++;
                points_cluster(idx_cluster, :) = points(qq, :);
            end
        end

        H = convhull(points_cluster(:, 1), points_cluster(:, 2));

        for qq = 1 : size(H)
            next_point_index = qq + 1;
            if next_point_index > size(H)
                next_point_index = 1;
            end

            curr_point = points_cluster(H(qq), 1:2);
            next_point = points_cluster(H(next_point_index), 1:2);

            % rasterize line
            newImg = bresenhamLine(newImg, curr_point, next_point, [0 0 0]);
        end

    end

    imshow(newImg);
    %}

    %% break;
end

nr_elements = length(imnames);
for pp=1:resize_factor
    for kk=1:resize_factor
        average_matrix(pp, kk) = average_matrix(pp, kk) / nr_elements;
    end
end

%% save('amplitude-average-matrix.txt', 'average_matrix', '-ascii');
